export class MethodResult {
    id: number;
    userId: number;
    title: String;
    body: String;
}